# Nome do jogo: Formando conjuntos

Este é um jogo de cartas para 2 jogadores.<br>
Inicialmente, cada jogador recebe 7 cartas.<br>
As cartas restantes são colocadas na mesa, viradas para baixo, formando uma pilha de compra de
cartas.<br>
Então, se sorteia quem vai jogar primeiro.<br>
Na vez de cada jogador, aquele jogador pede ao seu oponente que lhe entregue todas as cartas que
ele tem na mão que tenham um determinado número (Por exemplo, "por favor, me entregue todos
os noves que você tiver").<br>
Se o oponente tiver cartas com aquele valor, ele precisa entregar todas elas, e então o mesmo
jogador que fez o pedido joga novamente (pode fazer um novo pedido).<br>
Se o oponente não tiver em sua mão cartas com aquele valor, ele simplesmente responde
"Não tenho, compra!". Nesse caso, o jogador que fez o pedido compra uma carta. Se a carta
comprada tiver o mesmo número que foi pedido, o jogador que a comprou mostra ao oponente, e
joga novamente (ou seja, faz um novo pedido). Se a carta comprada não coincidir com o número
que havia sido pedido, o jogador simplesmente a coloca em sua mão e passa a vez.<br>
Se um jogador conseguir juntar 4 cartas de mesmo valor, seja pedindo as cartas do oponente, seja
pescando, ele revela que conseguiu formar esse "conjunto" e coloca essas 4 cartas viradas para
baixo na sua frente (ou seja, elas não fazem mais parte das cartas da sua mão).<br>
O jogo continua até que alguém não tenha mais cartas na mão ou a pilha de compra termine.
Ao fim do jogo, o jogador que conseguiu juntar mais "conjuntos" de 4 cartas de mesmo valor
ganha.